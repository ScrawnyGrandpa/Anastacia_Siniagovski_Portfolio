const addElementBtn = document.getElementById('addElementBtn');
const colorInput = document.getElementById('colorInput');
const rightPanel = document.getElementById('rightPanel');
const elementType = document.getElementById('elementType');
const elementWidth = document.getElementById('elementWidth');
const elementHeight = document.getElementById('elementHeight');
const contentColor = document.getElementById('contentColor');
const elementContent = document.getElementById('elementContent');
const contentFont = document.getElementById('contentFont');
const contentFontSize = document.getElementById('contentFontSize');
const resetInputsBtn = document.getElementById('resetInputsBtn');
const saveInputsBtn = document.getElementById('saveInputsBtn');
const refreshBtn = document.getElementById('refreshBtn');

addElementBtn.addEventListener('click', () => {
    /*     let newUserElement = document.createElement("div"); */

    let newUserElement;
    if (elementType.value === "") {
        newUserElement = document.createElement("div");
    } else {
        newUserElement = document.createElement(elementType.value);
    }

    elementWidth.value == '' ? newUserElement.style.width = '600px' : newUserElement.style.width = elementWidth.value + 'px';
    elementHeight.value == '' ? newUserElement.style.height = '150px' : newUserElement.style.height = elementHeight.value + 'px';

    newUserElement.style.fontFamily = contentFont.value;
    newUserElement.style.fontSize = contentFontSize.value + 'rem';
    newUserElement.innerHTML = elementContent.value;
    newUserElement.style.color = contentColor.value;
    newUserElement.style.backgroundColor = colorInput.value;
    rightPanel.appendChild(newUserElement);

});

resetInputsBtn.addEventListener('click', () => {
    elementType.value = " ";
    elementWidth.value = " ";
    elementHeight.value = " ";
    contentColor.value = " ";
    elementContent.value = " ";
    contentFont.value = " ";
    contentFontSize.value = " ";
    colorInput.value = " ";
});

saveInputsBtn.addEventListener('click', () => { });

refreshBtn.addEventListener('click', () => {
    location.reload()
});