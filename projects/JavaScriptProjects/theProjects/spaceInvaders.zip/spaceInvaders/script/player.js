export default class Player {
    x;
    y;
    width;
    height;
    speed;
    color;

    constructor() {
        this.x = 60;
        this.y = 400;
        this.width = 40;
        this.height = 18;
        this.speed = 40;
        this.color = "blue";
    }
}